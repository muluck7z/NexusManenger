import requests
import time
import random
import os
import sys
import shutil
import getpass
import itertools
import json
import urllib3
import base64

# Silenciar avisos
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    CYAN = '\033[96m'
    MAGENTA = '\033[95m'
    BLUE = '\033[94m'
    BOLD = '\033[1m'
    END = '\033[0m'

class MemoryManager:
    def __init__(self, learnings_file="learnings.json", instructions_file="instrucoes.txt"):
        self.learnings_file = learnings_file
        self.instructions_file = instructions_file
        self.history_dir = "user_histories"
        
        if not os.path.exists(self.history_dir):
            os.makedirs(self.history_dir)
            
        self.learnings = self._load_json(self.learnings_file)
        self._ensure_instructions_file()

    def _ensure_instructions_file(self):
        if not os.path.exists(self.instructions_file):
            with open(self.instructions_file, 'w', encoding='utf-8') as f:
                f.write("Você é uma IA com visão computacional. Analise imagens e responda de forma útil.")

    def get_instructions(self):
        try:
            with open(self.instructions_file, 'r', encoding='utf-8') as f:
                return f.read().strip()
        except: return "Você é uma IA com visão computacional."

    def _load_json(self, filename):
        if os.path.exists(filename):
            try:
                with open(filename, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except: return {}
        return {}

    def _save_json(self, filename, data):
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)

    def get_user_history_file(self, user_id, username):
        clean_username = "".join([c for c in str(username) if c.isalnum() or c in (' ', '_')]).strip().replace(" ", "_")
        return os.path.join(self.history_dir, f"{user_id}_{clean_username}.json")

    def get_history(self, user_id, username):
        filename = self.get_user_history_file(user_id, username)
        data = self._load_json(filename)
        # Agora retorna TODO o histórico para a IA ler a conversa inteira
        return data.get("messages", [])

    def add_to_history(self, user_id, username, role, content):
        filename = self.get_user_history_file(user_id, username)
        data = self._load_json(filename)
        if "messages" not in data: data["messages"] = []
        
        data["messages"].append({"role": role, "content": content, "timestamp": time.time()})
        # Mantemos um limite de 100 mensagens para não estourar o limite técnico da IA, mas garantindo memória longa
        if len(data["messages"]) > 100:
            data["messages"] = data["messages"][-100:]
            
        self._save_json(filename, data)

    def add_learning(self, user_id, teaching):
        user_id = str(user_id)
        if "general" not in self.learnings: self.learnings["general"] = []
        self.learnings["general"].append({"user": user_id, "teaching": teaching, "timestamp": time.time()})
        self._save_json(self.learnings_file, self.learnings)

    def get_all_learnings(self):
        return self.learnings.get("general", [])

class AIManager:
    def __init__(self, api_keys):
        self.api_keys = api_keys
        self.current_key_index = 0
        self.endpoint = "https://api.groq.com/openai/v1/chat/completions"
        self.vision_model = "llama-3.2-90b-vision-preview"
        self.text_model = "llama-3.3-70b-versatile"

    def get_current_key(self):
        return self.api_keys[self.current_key_index]

    def rotate_key(self):
        self.current_key_index = (self.current_key_index + 1) % len(self.api_keys)
        print_log("🔄", f"Limite atingido. Trocando para a chave {self.current_key_index + 1}", Colors.YELLOW)

    def encode_image_from_url(self, url):
        try:
            response = requests.get(url, timeout=15, stream=True)
            content = b""
            for chunk in response.iter_content(chunk_size=1024):
                content += chunk
                if len(content) > 2 * 1024 * 1024: break
            return base64.b64encode(content).decode('utf-8')
        except: return None

    def generate_response(self, user_id, username, user_message, memory, image_url=None):
        for _ in range(len(self.api_keys)):
            result = self._attempt_request(user_id, username, user_message, memory, image_url)
            if isinstance(result, str) and "Status: 429" in result:
                self.rotate_key()
                continue
            return result
        return "Todas as chaves API falharam."

    def _attempt_request(self, user_id, username, user_message, memory, image_url=None):
        history = memory.get_history(user_id, username)
        learnings = memory.get_all_learnings()
        custom_instructions = memory.get_instructions()
        
        learning_context = ""
        if learnings:
            learning_context = "\n\n### BASE DE CONHECIMENTO CRÍTICA (REGRAS ABSOLUTAS):\n"
            for idx, l in enumerate(learnings, 1):
                learning_context += f"- {l['teaching']}\n"
            learning_context += "\nIMPORTANTE: Se as informações acima contradizem o que você acha ou o que foi dito antes no chat, IGNORE o erro anterior e siga RIGOROSAMENTE a Base de Conhecimento acima."
        
        system_msg = f"You are a helpful multilingual assistant. {custom_instructions}\n\n{learning_context}\n\nINSTRUÇÃO: Você pode conversar naturalmente sobre qualquer assunto, mas se o assunto for relacionado a trocas ou regras contidas na Base de Conhecimento acima, você deve obedecê-las 100%. Nunca contradiga os aprendizados."
        
        messages = [{"role": "system", "content": system_msg}]
        for msg in history:
            messages.append({"role": msg["role"], "content": msg["content"]})
            
        lang_instruction = f"\n\n[IMPORTANT: Respond to the user in the SAME language they used: '{user_message[:50]}...'. Translate all facts from the knowledge base to their language.]"
        
        if image_url:
            base64_image = self.encode_image_from_url(image_url)
            if base64_image:
                user_content = [{"type": "text", "text": (user_message if user_message else "Analise esta imagem.") + lang_instruction},
                                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}}]
                messages.append({"role": "user", "content": user_content})
                model = self.vision_model
            else:
                messages.append({"role": "user", "content": user_message + " (Imagem enviada, mas não processada)" + lang_instruction})
                model = self.text_model
        else:
            messages.append({"role": "user", "content": user_message + lang_instruction})
            model = self.text_model

        headers = {"Authorization": f"Bearer {self.get_current_key()}", "Content-Type": "application/json"}
        payload = {"model": model, "messages": messages, "temperature": 0.7}

        try:
            res = requests.post(self.endpoint, headers=headers, json=payload, timeout=45)
            if res.status_code == 200:
                ai_response = res.json()['choices'][0]['message']['content']
                return ai_response
            return f"Erro na IA (Status: {res.status_code})"
        except Exception as e:
            return f"Erro de conexão: {e}"

def get_term_width():
    return shutil.get_terminal_size().columns

def print_header(title, color=Colors.CYAN):
    os.system('cls' if os.name == 'nt' else 'clear')
    width = get_term_width()
    formatted_title = f"--- {title} ---"
    print(f"\n{color}{formatted_title.center(width)}{Colors.END}\n")

def print_log(icon, message, color):
    print(f"{color}--- [{icon}] {message} ---{Colors.END}")

def spinner_animation(duration, message):
    spinner = itertools.cycle(['⠇', '⠏', '⠋', '⠙', '⠸', '⠴', '⠦', '⠧'])
    end_time = time.time() + duration
    while time.time() < end_time:
        display_text = f"--- {next(spinner)} {message}... ---"
        sys.stdout.write(f'\r{Colors.YELLOW}{display_text}{Colors.END}')
        sys.stdout.flush()
        time.sleep(0.1)
    sys.stdout.write('\r' + ' ' * (len(message) + 15) + '\r')

def get_ultra_headers(token):
    return {
        "authority": "discord.com", "authorization": token, "content-type": "application/json",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    }

def send_message(token, channel_id, message):
    headers = get_ultra_headers(token)
    try: requests.post(f"https://discord.com/api/v9/channels/{channel_id}/typing", headers=headers, timeout=5)
    except: pass
    time.sleep(random.uniform(2, 4))
    payload = {"content": message, "nonce": str(random.randint(10**18, 10**19))}
    try:
        res = requests.post(f"https://discord.com/api/v9/channels/{channel_id}/messages", headers=headers, json=payload)
        return res.status_code == 200
    except: return False

def handle_friend_requests(token):
    headers = get_ultra_headers(token)
    try:
        res = requests.get("https://discord.com/api/v9/users/@me/relationships", headers=headers, timeout=10)
        if res.status_code == 200:
            for rel in res.json():
                if rel.get('type') == 3:
                    requests.put(f"https://discord.com/api/v9/users/@me/relationships/{rel['id']}", headers=headers, json={}, timeout=10)
                    print_log("🤝", f"Pedido de amizade aceito: {rel['user']['username']}", Colors.GREEN)
    except: pass

def block_user(token, user_id):
    headers = get_ultra_headers(token)
    try:
        requests.put(f"https://discord.com/api/v9/users/@me/relationships/{user_id}", headers=headers, json={"type": 2}, timeout=10)
        return True
    except: return False

def main_loop(token, ai_manager, memory, my_id):
    last_message_ids = {}
    headers = get_ultra_headers(token)
    responded_count = 0
    
    print_header("NexusDM AI - FINAL VERSION", Colors.MAGENTA)
    print_log("📈", f"{responded_count} usuários na sua DM", Colors.CYAN)
    
    while True:
        try:
            handle_friend_requests(token)
            channels_res = requests.get("https://discord.com/api/v9/users/@me/channels", headers=headers, timeout=15)
            if channels_res.status_code != 200:
                time.sleep(20); continue

            channels = channels_res.json()
            for channel in channels:
                if channel.get('type') == 1:
                    channel_id = channel['id']
                    user_id = next((r['id'] for r in channel['recipients'] if r['id'] != my_id), None)
                    if not user_id or last_message_ids.get(channel_id) == "CANCELLED": continue
                    
                    m_res = requests.get(f"https://discord.com/api/v9/channels/{channel_id}/messages?limit=1", headers=headers, timeout=10)
                    if m_res.status_code == 200 and m_res.json():
                        last_msg = m_res.json()[0]
                        if last_msg['id'] != last_message_ids.get(channel_id) and last_msg['author']['id'] != my_id:
                            last_message_ids[channel_id] = last_msg['id']
                            user_text = last_msg.get('content', '')
                            username = last_msg['author']['username']
                            
                            image_url = None
                            if last_msg.get('attachments'):
                                for att in last_msg['attachments']:
                                    if att.get('content_type', '').startswith('image/'):
                                        image_url = att['url']; break
                            
                            # Cria o histórico IMEDIATAMENTE ao receber a mensagem
                            memory.add_to_history(user_id, username, "user", user_text if user_text else "[Imagem Enviada]")

                            if user_text.lower().startswith("aprenda:"):
                                teaching = user_text[8:].strip()
                                memory.add_learning(user_id, teaching)
                                response = f"Entendido! Aprendi: '{teaching}'."
                            else:
                                print_log("🤖", f"Nova interação de {username}", Colors.BLUE)
                                response = ai_manager.generate_response(user_id, username, user_text, memory, image_url)
                            
                            # Removida a regra de ignorar para permitir conversação natural

                            send_message(token, channel_id, response)
                            memory.add_to_history(user_id, username, "assistant", response)
                            
                            responded_count += 1
                            print_header("NexusDM AI - FINAL VERSION", Colors.MAGENTA)
                            print_log("📈", f"{responded_count} usuários na sua DM", Colors.CYAN)
                            print_log("✅", f"Respondido: {username}", Colors.GREEN)

                            if response.strip().upper() == "OK":
                                print_log("⏳", f"Aguardando 2 min para cancelar...", Colors.CYAN)
                                time.sleep(120)
                                cancel_msg = "Não, infelizmente não consegui adicionar você. Teremos que cancelar nossa troca. Desejo boa sorte a você em outras trocas!"
                                send_message(token, channel_id, cancel_msg)
                                block_user(token, user_id)
                                print_log("🛑", f"Usuário bloqueado: {username}", Colors.RED)
                                last_message_ids[channel_id] = "CANCELLED"
                                continue

                            if "Não, infelizmente não consegui adicionar você" in response:
                                block_user(token, user_id)
                                print_log("🛑", f"Usuário bloqueado: {username}", Colors.RED)
                                last_message_ids[channel_id] = "CANCELLED" 
                                continue

            wait = random.randint(15, 30)
            for i in range(wait, 0, -1):
                sys.stdout.write(f"\r{Colors.YELLOW}--- [🛡️] Próxima varredura em {i:02d}s ---{Colors.END}")
                sys.stdout.flush()
                time.sleep(1)
            sys.stdout.write('\r' + ' ' * 50 + '\r')
        except: time.sleep(20)

def load_profiles():
    if os.path.exists("profiles.json"):
        with open("profiles.json", "r") as f: return json.load(f)
    return {}

def save_profile(name, token, api_keys):
    profiles = load_profiles()
    profiles[name] = {"token": token, "api_keys": api_keys}
    with open("profiles.json", "w") as f: json.dump(profiles, f, indent=4)

def main():
    try:
        print_header("NexusDM AI Final", Colors.CYAN)
        profiles = load_profiles()
        token, api_keys = None, []

        if profiles:
            print(f"{Colors.CYAN}Perfis salvos:{Colors.END}")
            profile_names = list(profiles.keys())
            for i, name in enumerate(profile_names, 1):
                print(f"{name} ({i})")
            print(f"Nenhum ({len(profile_names) + 1})")
            choice = input(f"\n{Colors.BOLD}Digite um número: {Colors.END}").strip()
            if choice.isdigit() and 1 <= int(choice) <= len(profile_names):
                selected = profile_names[int(choice) - 1]
                token = profiles[selected]["token"]
                api_keys = profiles[selected]["api_keys"]
                print_log("📂", f"Perfil '{selected}' carregado!", Colors.GREEN)
            else:
                print_log("🆕", "Criando nova configuração...", Colors.YELLOW)

        if not token:
            token = getpass.getpass(f"{Colors.BOLD}Token Discord: {Colors.END}")
            print(f"\n{Colors.CYAN}Configuração de 5 Chaves API (Groq):{Colors.END}")
            for i in range(1, 6):
                key = getpass.getpass(f"{Colors.BOLD}Chave API {i}: {Colors.END}")
                if key: api_keys.append(key)
            if not api_keys:
                print(f"{Colors.RED}Nenhuma chave API fornecida!{Colors.END}"); return
            save_choice = input(f"\n{Colors.YELLOW}Você quer salvar essa informação? (S/n): {Colors.END}").strip().lower()
            if save_choice == 's' or save_choice == '':
                profile_name = input(f"{Colors.BOLD}Digite o nome do salvamento: {Colors.END}").strip()
                if profile_name:
                    save_profile(profile_name, token, api_keys)
                    print_log("💾", f"Perfil '{profile_name}' salvo!", Colors.GREEN)

        spinner_animation(1.5, "Validando Token")
        headers = get_ultra_headers(token)
        res = requests.get("https://discord.com/api/v9/users/@me", headers=headers, timeout=15)
        if res.status_code != 200:
            print(f"{Colors.RED}Token inválido!{Colors.END}"); return
        user = res.json()
        print(f"{Colors.GREEN}Logado como {user['username']}{Colors.END}")
        memory = MemoryManager()
        ai_manager = AIManager(api_keys)
        main_loop(token, ai_manager, memory, user['id'])
    except Exception as e:
        print(f"{Colors.RED}Erro crítico: {e}{Colors.END}")

if __name__ == "__main__":
    main()
